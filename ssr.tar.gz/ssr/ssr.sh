basepath=$(cd `dirname $0`; pwd)
cd $basepath/shadowsocks
python local.py -d start

