chmod +x /etc/rc.local
echo $(pwd)/ssr.sh >>/etc/rc.local
echo "$(pwd)/ssr.sh>>/etc/rc.local"
cat /etc/rc.local
