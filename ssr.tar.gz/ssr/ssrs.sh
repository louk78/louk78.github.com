curpath=$(cd `dirname $0`; pwd)
cd $curpath/shadowsocks
python local.py -d stop
